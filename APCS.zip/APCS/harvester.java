import kareltherobot.*;

public class harvester extends UrRobot
{
   public harvester(int street, int avenue, Direction direction, int beepers)
   
   {
      super (street, avenue, direction, beepers);
   }
   public void turnRight()
   {
      turnLeft();
      turnLeft();
      turnLeft();
   }
   public void stair()
   {
      pickBeeper();
      move();
      turnLeft();
      move();
      turnRight();
   }
   public void fourStair()
   {
      move();
      stair();
      stair();
      stair();
      pickBeeper();
   }
   public void resetTop()
   {
      move();
      move();
      turnRight();
      move();
      turnRight();
   }
   public static void main (String[] args)
   {
      World.readWorld("harvest.kwld");
      World.setDelay(5);
      World.setVisible(true);
         
      harvester jar = new harvester(1, 6, North, 0);
      
      jar.fourStair();
      jar.resetTop();
      jar.fourStair();
      jar.turnLeft();
      jar.move();
      jar.turnLeft();
      jar.fourStair();
      jar.resetTop();
      jar.fourStair();
   }
}